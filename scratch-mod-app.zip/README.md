# Scratch Mod (Android app)

A small Android app that opens the Scratch editor with the mod (dark theme, accent color, compact UI) applied.

## Get the APK (from your phone)

1. Create a free account at github.com and make a new repository (for example `scratch-mod`).
2. Upload everything in this folder to it, keeping the folder layout. The `.github/workflows/build.yml` file must be included.
   (On a phone browser: Add file, Upload files. If hidden folders won't upload, create `.github/workflows/build.yml` with "Create new file" and paste its contents.)
3. Open the **Actions** tab. The "Build APK" run starts on its own and takes about 3 to 5 minutes.
4. Open the finished run, scroll to **Artifacts**, and download **ScratchMod-apk**. It is a zip containing `app-debug.apk`.
5. Open the APK and allow "Install unknown apps" for your browser or file manager when Android asks.

## Notes

- The mod script is `app/src/main/assets/mod.js`. Edit it to change the theme.
- The app signs the APK with the standard debug key, which is fine for personal use.
- Scratch's editor is made for desktop screens, so the app asks for the desktop site and you can pinch to zoom.
